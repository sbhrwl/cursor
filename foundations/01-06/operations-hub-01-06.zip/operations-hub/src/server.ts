import http from 'node:http';
import pg from 'pg';
import {createHandler} from './handler.js';
const pool=new pg.Pool({connectionString:process.env.DATABASE_URL});
const server=http.createServer(createHandler({
 probeHealth:async()=>{await pool.query('select 1');},
 listDemoRequests:async()=>(await pool.query('select id,tenant_id,title,status from course_demo_requests order by id')).rows
}));
server.listen(3100,'127.0.0.1',()=>console.log('Operations baseline listening on 3100'));
process.on('SIGTERM',()=>server.close(()=>pool.end().then(()=>process.exit(0))));
