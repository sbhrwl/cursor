---
name: verify-change
description: Verify a bounded course code change and produce a reviewable handoff.
---
1. Inspect git status and diff.
2. Map changed behavior to an observable acceptance criterion.
3. Run the targeted tests and appropriate baseline check from README.md.
4. Inspect the actual service response or browser result when relevant.
5. Report changed behavior, checks, failures and remaining limitations.
