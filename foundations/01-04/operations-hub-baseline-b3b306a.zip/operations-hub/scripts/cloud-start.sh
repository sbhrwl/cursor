#!/usr/bin/env bash
# Cloud Agent start phase: short-lived and idempotent. Runs on every boot.
# It starts the local PostgreSQL cluster, ensures the synthetic course
# role/database, writes a local .env, seeds demo data, launches the API in the
# background, and then returns. It does not stay attached.
set -euo pipefail

cd "$(dirname "$0")/.."

# Local-only, synthetic credentials for an ephemeral dev database bound to
# localhost. This is not a real secret and matches the course's demo data.
DB_USER="course"
DB_PASSWORD="course"
DB_NAME="operations_hub"
DATABASE_URL="postgresql://${DB_USER}:${DB_PASSWORD}@localhost:5432/${DB_NAME}"
API_PORT="3100"
API_LOG="/tmp/operations-hub-dev.log"

PGVER="$(pg_lsclusters -h 2>/dev/null | awk 'NR==1{print $1}')"
PGCLUSTER="$(pg_lsclusters -h 2>/dev/null | awk 'NR==1{print $2}')"
: "${PGVER:=16}"
: "${PGCLUSTER:=main}"

STATUS="$(pg_lsclusters -h 2>/dev/null | awk 'NR==1{print $4}')"
if [ "${STATUS}" != "online" ]; then
  echo "[start] Starting PostgreSQL cluster ${PGVER}/${PGCLUSTER}"
  sudo pg_ctlcluster "${PGVER}" "${PGCLUSTER}" start
else
  echo "[start] PostgreSQL cluster ${PGVER}/${PGCLUSTER} already online"
fi

# Wait for the server to accept connections.
for _ in $(seq 1 30); do
  if sudo -u postgres pg_isready -q; then break; fi
  sleep 1
done

echo "[start] Ensuring role '${DB_USER}' and database '${DB_NAME}'"
sudo -u postgres psql -v ON_ERROR_STOP=1 <<SQL
DO \$\$
BEGIN
  IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname='${DB_USER}') THEN
    CREATE ROLE ${DB_USER} LOGIN PASSWORD '${DB_PASSWORD}';
  ELSE
    ALTER ROLE ${DB_USER} LOGIN PASSWORD '${DB_PASSWORD}';
  END IF;
END\$\$;
SQL
sudo -u postgres psql -tAc "SELECT 1 FROM pg_database WHERE datname='${DB_NAME}'" | grep -q 1 \
  || sudo -u postgres createdb -O "${DB_USER}" "${DB_NAME}"

if [ ! -f .env ]; then
  echo "[start] Writing .env"
  printf 'DATABASE_URL=%s\n' "${DATABASE_URL}" > .env
fi

echo "[start] Seeding synthetic demo data (db:init)"
DATABASE_URL="${DATABASE_URL}" npm run db:init

# Launch the API in the background, detached from this short-lived start shell so
# it keeps running after start returns. Skip if it is already serving.
if curl -sf "http://127.0.0.1:${API_PORT}/health" >/dev/null 2>&1; then
  echo "[start] API already listening on ${API_PORT}"
else
  echo "[start] Launching API in the background (logs: ${API_LOG})"
  setsid bash -c "exec npm run dev" >"${API_LOG}" 2>&1 </dev/null &
  for _ in $(seq 1 30); do
    if curl -sf "http://127.0.0.1:${API_PORT}/health" >/dev/null 2>&1; then break; fi
    sleep 1
  done
fi

if curl -sf "http://127.0.0.1:${API_PORT}/health" >/dev/null 2>&1; then
  echo "[start] API is healthy on http://127.0.0.1:${API_PORT}"
else
  echo "[start] ERROR: API did not become healthy on ${API_PORT}; see ${API_LOG}"
  tail -n 20 "${API_LOG}" 2>/dev/null || true
  exit 1
fi

echo "[start] Ready. DATABASE_URL points at localhost:5432/${DB_NAME}"
