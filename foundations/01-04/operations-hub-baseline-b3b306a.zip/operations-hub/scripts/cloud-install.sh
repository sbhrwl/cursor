#!/usr/bin/env bash
# Cloud Agent install phase: idempotent, baked into the environment snapshot.
# Installs the PostgreSQL server/client and Node dependencies. It must not
# start long-running processes; per-boot service startup lives in cloud-start.sh.
set -euo pipefail

cd "$(dirname "$0")/.."

if ! command -v psql >/dev/null 2>&1; then
  echo "[install] Installing PostgreSQL via apt"
  sudo apt-get update -qq
  sudo DEBIAN_FRONTEND=noninteractive apt-get install -y -qq postgresql postgresql-client
else
  echo "[install] PostgreSQL already present: $(psql --version)"
fi

echo "[install] Installing Node dependencies with npm ci"
npm ci

echo "[install] Done"
