import pg from 'pg';
const c=new pg.Client({connectionString:process.env.DATABASE_URL}); await c.connect();
try {await c.query('CREATE TABLE IF NOT EXISTS course_demo_requests(id integer PRIMARY KEY,tenant_id text NOT NULL,title text NOT NULL,status text NOT NULL)');for(const row of [[1,'demo-acme','Laptop approval','open'],[2,'demo-northwind','Training request','approved']]) await c.query('INSERT INTO course_demo_requests VALUES ($1,$2,$3,$4) ON CONFLICT(id) DO NOTHING',row);} finally {await c.end();}
