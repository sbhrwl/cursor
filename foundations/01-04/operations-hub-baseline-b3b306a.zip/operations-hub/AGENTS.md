# Superposition Cursor course
This is an environment baseline, not the finished course application.
Use synthetic demo data. Keep edits bounded to the current lesson.
Read README.md before starting; inspect git status and the current diff.
Verify changes with the relevant tests and runtime evidence.
Do not claim a service or integration works just because configuration exists.
Secrets live outside repositories. Never print tokens or copy them into commits.
Course MCP: health checks and read-only synthetic requests.
GitHub MCP uses the authenticated course GitHub CLI on AgentBox.
Cloud agents must use their own repository authentication and runtime-specific MCP configuration; AgentBox executable paths are not portable.
