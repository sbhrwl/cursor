# operations-hub

Prepared environment baseline for Cursor Engineering Masterclass.

This repository is intentionally a starter: full course features are built in the lessons.

Inside AgentBox, use `/workspace/cursor-course/bin/start-course` to start all three baseline services.
Use `/workspace/cursor-course/bin/check-course` to verify runtime dependencies.

See `/workspace/cursor-course/docs/SETUP.md` for ports, MCPs and account requirements.

## Standalone bootstrap

Install Node.js 22.12+ and Docker Compose. Set POSTGRES_PASSWORD, then run docker compose up -d. Copy .env.example to .env and insert the matching local password. Run npm ci, npm run db:init, npm test, npm run typecheck, and npm run dev.

In AgentBox, PostgreSQL is already reachable at course-postgres on a private network. Run commands with the environment from /workspace/cursor-course/config/private/services.env.

GitHub Actions CI passed on 2026-09-06: dependency install, database initialization, TypeScript check, and database integration test.

## AgentBox MCP configuration

The local `.cursor/mcp.json` is intentionally ignored: it contains machine-specific executable paths. `.cursor/mcp.agentbox.example.json` documents the isolated course machine configuration. Do not enable that example unchanged on a Cloud Agent or another computer. Configure MCP commands for that runtime. No credentials are stored in either configuration.
