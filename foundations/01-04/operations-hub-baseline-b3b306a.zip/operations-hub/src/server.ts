import http from 'node:http';
import pg from 'pg';
const pool=new pg.Pool({connectionString:process.env.DATABASE_URL});
const server=http.createServer(async(req,res)=>{
 res.setHeader('Content-Type','application/json');
 try {
  if(req.url==='/health') {await pool.query('select 1');res.end(JSON.stringify({status:'ok',service:'operations-hub',database:'connected',stage:'environment-baseline'}));}
  else if(req.url==='/demo/requests') {const r=await pool.query('select id,tenant_id,title,status from course_demo_requests order by id');res.end(JSON.stringify(r.rows));}
  else {res.statusCode=404;res.end(JSON.stringify({error:'not_found'}));}
 } catch {res.statusCode=503;res.end(JSON.stringify({status:'unavailable'}));}
});
server.listen(3100,'127.0.0.1',()=>console.log('Operations baseline listening on 3100'));
process.on('SIGTERM',()=>server.close(()=>pool.end().then(()=>process.exit(0))));
