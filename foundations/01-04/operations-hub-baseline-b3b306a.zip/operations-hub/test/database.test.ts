import test from 'node:test';
import assert from 'node:assert/strict';
import pg from 'pg';
test('database accepts a transaction and rolls back a synthetic request',async()=>{
 const c=new pg.Client({connectionString:process.env.DATABASE_URL});await c.connect();
 try {await c.query('BEGIN');await c.query("insert into course_demo_requests(id,tenant_id,title,status) values(999,'demo-acme','rollback probe','open')");assert.equal((await c.query('select id from course_demo_requests where id=999')).rowCount,1);await c.query('ROLLBACK');assert.equal((await c.query('select id from course_demo_requests where id=999')).rowCount,0);}finally{await c.end();}
});
