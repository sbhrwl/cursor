import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import type {AddressInfo} from 'node:net';
import {createHandler,type HandlerDeps} from '../src/handler.js';

type HttpResult={status:number;headers:http.IncomingHttpHeaders;body:string};

function request(origin:string,path:string,method:string){
 return new Promise<HttpResult>((resolve,reject)=>{
  const req=http.request(`${origin}${path}`,{method,signal:AbortSignal.timeout(2000)},res=>{
   const chunks:Buffer[]=[];
   res.on('data',chunk=>chunks.push(chunk as Buffer));
   res.on('end',()=>resolve({status:res.statusCode??0,headers:res.headers,body:Buffer.concat(chunks).toString('utf8')}));
  });
  req.on('error',reject);
  req.end();
 });
}

async function withServer(deps:HandlerDeps,run:(origin:string)=>Promise<void>){
 const server=http.createServer(createHandler(deps));
 await new Promise<void>(resolve=>server.listen(0,'127.0.0.1',resolve));
 const address=server.address() as AddressInfo;
 try {await run(`http://127.0.0.1:${address.port}`);}
 finally {await new Promise<void>((resolve,reject)=>server.close(err=>err?reject(err):resolve()));}
}

test('healthy GET /health returns 200 metadata and probes once',async()=>{
 let probes=0;
 await withServer({
  probeHealth:async()=>{probes+=1;},
  listDemoRequests:async()=>{throw new Error('unused');}
 },async origin=>{
  const res=await request(origin,'/health','GET');
  assert.equal(res.status,200);
  assert.equal(res.headers['content-type'],'application/json');
  assert.deepEqual(JSON.parse(res.body),{status:'ok',service:'operations-hub',database:'connected',stage:'environment-baseline'});
  assert.equal(probes,1);
 });
});

test('healthy HEAD /health returns 200 with no body and probes once',async()=>{
 let probes=0;
 await withServer({
  probeHealth:async()=>{probes+=1;},
  listDemoRequests:async()=>{throw new Error('unused');}
 },async origin=>{
  const res=await request(origin,'/health','HEAD');
  assert.equal(res.status,200);
  assert.equal(res.headers['content-type'],'application/json');
  assert.equal(res.body,'');
  assert.equal(probes,1);
 });
});

test('failing probe returns 503 for GET and empty-body HEAD',async()=>{
 await withServer({
  probeHealth:async()=>{throw new Error('probe failed');},
  listDemoRequests:async()=>{throw new Error('unused');}
 },async origin=>{
  const get=await request(origin,'/health','GET');
  assert.equal(get.status,503);
  assert.deepEqual(JSON.parse(get.body),{status:'unavailable'});
  const head=await request(origin,'/health','HEAD');
  assert.equal(head.status,503);
  assert.equal(head.body,'');
 });
});

test('unsupported /health methods return 405 without probing',async()=>{
 let probes=0;
 await withServer({
  probeHealth:async()=>{probes+=1;},
  listDemoRequests:async()=>{throw new Error('unused');}
 },async origin=>{
  for(const method of ['POST','PUT','DELETE','PATCH','OPTIONS']) {
   const res=await request(origin,'/health',method);
   assert.equal(res.status,405);
   assert.equal(res.headers.allow,'GET, HEAD');
   assert.deepEqual(JSON.parse(res.body),{error:'method_not_allowed'});
  }
  assert.equal(probes,0);
 });
});

test('failing demo-list dependency preserves 503',async()=>{
 await withServer({
  probeHealth:async()=>{throw new Error('unused');},
  listDemoRequests:async()=>{throw new Error('demo list failed');}
 },async origin=>{
  const res=await request(origin,'/demo/requests','GET');
  assert.equal(res.status,503);
  assert.deepEqual(JSON.parse(res.body),{status:'unavailable'});
 });
});

test('unknown paths remain 404 and demo requests stay available',async()=>{
 const rows=[{id:1,tenant_id:'demo-acme',title:'Laptop approval',status:'open'}];
 await withServer({
  probeHealth:async()=>{throw new Error('unused');},
  listDemoRequests:async()=>rows
 },async origin=>{
  const missing=await request(origin,'/missing','GET');
  assert.equal(missing.status,404);
  assert.deepEqual(JSON.parse(missing.body),{error:'not_found'});
  const demo=await request(origin,'/demo/requests','GET');
  assert.equal(demo.status,200);
  assert.deepEqual(JSON.parse(demo.body),rows);
 });
});
