import type {IncomingMessage,ServerResponse} from 'node:http';

export type HandlerDeps={
 probeHealth:()=>Promise<void>;
 listDemoRequests:()=>Promise<unknown>;
};

const healthOk=JSON.stringify({status:'ok',service:'operations-hub',database:'connected',stage:'environment-baseline'});

export function createHandler(deps:HandlerDeps){
 return async(req:IncomingMessage,res:ServerResponse)=>{
  res.setHeader('Content-Type','application/json');
  try {
   if(req.url==='/health') {
    if(req.method!=='GET'&&req.method!=='HEAD') {
     res.statusCode=405;
     res.setHeader('Allow','GET, HEAD');
     res.end(JSON.stringify({error:'method_not_allowed'}));
     return;
    }
    await deps.probeHealth();
    if(req.method==='HEAD') {res.end();return;}
    res.end(healthOk);
   }
   else if(req.url==='/demo/requests') {res.end(JSON.stringify(await deps.listDemoRequests()));}
   else {res.statusCode=404;res.end(JSON.stringify({error:'not_found'}));}
  } catch {
   res.statusCode=503;
   if(req.url==='/health'&&req.method==='HEAD') {res.end();return;}
   res.end(JSON.stringify({status:'unavailable'}));
  }
 };
}
